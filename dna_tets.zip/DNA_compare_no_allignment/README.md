this is an implementation to compare DNA sequences without alignment. 
